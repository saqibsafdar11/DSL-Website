# setup #
# load libraries ----


# load in dataset ----


# clean your data #
# fix height and weight columns ----


# make new columns in the dataset with your calculations for each person (BMI, WHR, Blood pressure) ----



# rename NA values in occupation as "unemployed" ----



# add bmi and whr ranges ----



# join data using lsoa information ----



# tidy up columns ----



# write/save data ----


